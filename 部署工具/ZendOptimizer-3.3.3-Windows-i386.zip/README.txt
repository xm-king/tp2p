Zend Optimizer installation instructions
-------------------------------------------

1. Extract the Zend Optimizer Zip file

2. Add the following directives to your php.ini
	[Zend]
	zend_extension_manager.optimizer_ts="<extracted location>\ZendOptimizer-3.3.3\Optimizer-3.3.3"
	zend_extension_ts="<extracted location>\ZendOptimizer-3.3.3\ZendExtensionManager.dll"
	
3. Restart your Web server.

5. Verify that both components are loaded using phpinfo() - Output should be:
	Zend Engine v2.2.0, Copyright (c) 1998-2010 Zend Technologies
	    with Zend Extension Manager v1.2.0, Copyright (c) 2003-2007, by Zend Technologies
    	    with Zend Optimizer v3.3.3, Copyright (c) 1998-2007, by Zend Technologies